#ifndef HQ3X_H
#define HQ3X_H

void hq3x_init(void);

void hq3x_32(void* pSrc, void* pDest, int Xres, int Yres, int BpL);

#endif

