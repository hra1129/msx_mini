#ifndef HQ2X_H
#define HQ2X_H

void hq2x_init(void);

void hq2x_32(void* pSrc, void* pDest, int Xres, int Yres, int BpL);

#endif

