/*
 * $Source: /cygdrive/d/Private/_SVNROOT/bluemsx/blueMSX/Src/Memory/MegaSCSIsub.h,v $
 *
 * $Revision: 1.6 $
 *
 * $Date: 2007-03-28 17:35:35 $
 *
 * Copyright (C) 2007 white cat
 *
 */
#ifndef MEGASCSISUB_H
#define MEGASCSISUB_H

#include "MsxTypes.h"

#define REG_DREG 10

int EseRamSize(int size);

#endif
